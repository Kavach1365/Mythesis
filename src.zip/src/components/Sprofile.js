// Import necessary React components and styles
import React, { useState } from 'react';
//import './App.css'; // You can customize the styling as needed

// Define the main functional component
export const Sprofile=()=> {
  // State variables to manage form data
  const [profilePhoto, setProfilePhoto] = useState(null);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [fathersName, setFathersName] = useState('');
  const [mothersName, setMothersName] = useState('');
  const [mobileNo, setMobileNo] = useState('');
  const [emailId, setEmailId] = useState('');
  const [residenceAddress, setResidenceAddress] = useState('');
  const [gender, setGender] = useState('');
  const [age, setAge] = useState('');
  const [region, setRegion] = useState('');
  const [state, setState] = useState('');
  const [collegeName, setCollegeName] = useState('');
  const [collegeAddress, setCollegeAddress] = useState('');
  const [branch, setBranch] = useState('');
  const [mentorName, setMentorName] = useState('');
  const [mentorEmail, setMentorEmail] = useState('');
  const [mentorPhone, setMentorPhone] = useState('');
  const [cgpa, setCGPA] = useState('');
  const [achievements, setAchievements] = useState('');
  const [uploadedFiles, setUploadedFiles] = useState([]);

  // Function to handle file upload
  const handleFileUpload = (event) => {
    const files = event.target.files;
    setProfilePhoto(files[0]);
  };

  // Function to handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Process the form data as needed
    console.log("Form Data:", {
      profilePhoto,
      firstName,
      lastName,
      fathersName,
      mothersName,
      mobileNo,
      emailId,
      residenceAddress,
      gender,
      age,
      region,
      state,
      collegeName,
      collegeAddress,
      branch,
      mentorName,
      mentorEmail,
      mentorPhone,
      cgpa,
      achievements,
      uploadedFiles,
    });
    // You can perform additional actions like sending data to a server here
  };

  return (
    <div className="App">
      <h2>Student Profile</h2>
      <form onSubmit={handleSubmit}>
        {/* Profile Photo */}
        <label>Profile Photo:</label>
        <input type="file" onChange={handleFileUpload} />

        {/* Personal Information */}
        <label>First Name:</label>
        <input type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
        {/* ... (similar structure for other text fields) */}

        {/* Gender */}
        <label>Gender:</label>
        <div>
          <label>
            <input type="radio" name="gender" value="male" checked={gender === 'male'} onChange={() => setGender('male')} />
            Male
          </label>
          <label>
            <input type="radio" name="gender" value="female" checked={gender === 'female'} onChange={() => setGender('female')} />
            Female
          </label>
        </div>

        {/* Age */}
        <label>Age:</label>
        <input type="number" value={age} onChange={(e) => setAge(e.target.value)} />

        {/* Region */}
        <label>Region:</label>
        <select value={region} onChange={(e) => setRegion(e.target.value)}>
          <option value="">Select Region</option>
          <option value="north">North</option>
          <option value="south">South</option>
          <option value="east">East</option>
          <option value="west">West</option>
        </select>

        {/* College Information */}
        {/* ... (similar structure for other college-related fields) */}

        {/* CGPA */}
        <label>CGPA:</label>
        <input type="text" value={cgpa} onChange={(e) => setCGPA(e.target.value)} />

        {/* Achievements */}
        <label>Achievements:</label>
        <textarea value={achievements} onChange={(e) => setAchievements(e.target.value)} />

        {/* File Upload for Achievements */}
        <label>Upload Achievement Files:</label>
        <input type="file" multiple onChange={(e) => setUploadedFiles(e.target.files)} />

        {/* Submit Button */}
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}
